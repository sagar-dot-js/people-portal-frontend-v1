import React from 'react'

const Select = () => {
  return (
    <div>Select</div>
  )
}

export default Select