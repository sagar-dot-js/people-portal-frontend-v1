import React, { useState } from "react";
import Button from "../components/Button";
import Modal from "../components/Modal/Modal";
import { ModalContent } from "../components/Modal/Modal.style";
import Radio, { RadioButton } from "../components/Radio/Radio";
import submitedImage from "../assets/submited.png";

const ResignationForm = () => {
  const [showModal, setShowModal] = useState(false);

  const openModal = () => {
    setShowModal((prev) => !prev);
    console.log(openModal);
  };
  return (
    <div className="custom-px flex justify-between ">
      <div className="h-[695px] resignation-from my-[53px] w-[50%] ">
        <div className="border-b flex justify-center p-[20px]">
          <h1 className="text-[24px] text-[600]">Apply for Resignation</h1>
        </div>
        <div className="px-[40px] py-[30px] flex flex-col gap-4">
          <div>
            <h2>Resign Date (By Default)</h2>
            <input type="date" />
          </div>
          <div>
            <h2>Serve Notice Period *</h2>
            <div className="mt-[10px] flex gap-10">
              <div className="flex ">
                {" "}
                <Radio></Radio>Yes
              </div>{" "}
              <div className="flex">
                <Radio></Radio>No
              </div>
            </div>
          </div>
          <div>
            <h2>Last working date</h2>
            <input type="date" />
          </div>
          <div>
            <h2>Why are you resigning from this job? *</h2>
            <input type="text" />
          </div>
          <div>
            <h2>
              Do you think management gave you enough opportunities to air your
              views? *
            </h2>
            <input type="text" />
          </div>
          <div className="mt-[30px]">
            <Button
              // onClick={(e) => console.log("its working", e)}
              variant="filled"
              className="w-full"
              onClick={() => openModal()}
            >
              Submit
            </Button>
          </div>
        </div>
      </div>
      <div className=" w-[50%]">{/* For Image  */}</div>

      <div>
        <Modal showModal={showModal} setShowModal={setShowModal}>
          <ModalContent>
            <div className="w-[400px] h-[266px] flex items-center flex-col justify-center text-center gap-3">
              <div className="w-[200px]">
                <img src={submitedImage} className="h-full w-full object-fit" />
              </div>

              <p className="text-[#333333] text-[24px] font-[700]">
                Submited..!
              </p>
              <p className="text-[#666666] text-[16px] font-[400]">
                {" "}
                Submission has been is received.
              </p>
              <p className="text-[#ACACAC] text-[12px]">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Netus
                adipiscing hendrerit adipiscing.
              </p>
            </div>
          </ModalContent>
        </Modal>
      </div>
    </div>
  );
};

export default ResignationForm;
