export const AlertVariant = {
  SUCCESS: "success",
  ERROR: "error",
  // ALERT: "alert",
  WARNING: "warning",
  ALTERNATIVE: "alternative",
};
